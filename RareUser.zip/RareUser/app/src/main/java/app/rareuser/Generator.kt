package app.rareuser

import kotlin.random.Random

enum class Mode(val label: String) {
    MIXED("الكل"),
    LETTERS("حروف فقط"),
    DIGITS("حروف + أرقام"),
    UNDERSCORE("مع _"),
    DOT("مع .")
}

data class Candidate(val name: String, val score: Int)

object Generator {
    private const val CONS = "bcdfghjklmnpqrstvwxyz"
    private const val VOW = "aeiou"
    private const val RARE = "qxzjkvwy"

    // كلمات وأسماء شائعة تُستبعد لأن احتمال أخذها كبير
    private val COMMON_WORDS = setOf(
        "the", "and", "you", "cat", "dog", "sun", "max", "sam", "tom", "ali", "ben", "bob",
        "omar", "amir", "adam", "john", "mike", "anna", "love", "cool", "king", "boss", "star",
        "moon", "girl", "baby", "lion", "home", "real", "best", "good", "god", "sex", "xxx",
        "abc", "xyz", "qwe", "asd", "zxc", "one", "two", "new", "top", "pro", "vip", "dev",
        "app", "web", "fun", "mom", "dad", "boy", "man", "sky", "sea", "red", "ice", "fox",
        "wolf", "dark", "fire", "blue", "gold", "lord", "mero", "mido", "zizo", "hoda", "nour",
        "lola", "dodo", "momo", "koko", "kiki", "lulu", "nana", "mama", "papa", "mimi"
    )

    private val COMMON_DIGITS = setOf(
        "0", "1", "2", "3", "7", "10", "11", "12", "21", "22", "23", "24", "25", "69", "77",
        "99", "00", "01", "100", "111", "123", "007", "000", "999", "777", "1234", "10"
    )

    private fun anyLetter(r: Random): Char = 'a' + r.nextInt(26)

    private fun rareOrAny(r: Random): Char =
        if (r.nextInt(3) == 0) RARE[r.nextInt(RARE.length)] else anyLetter(r)

    /** جزء الحروف: 3 أو 4 حروف بأشكال مختلفة (متناظر، مكرر، قابل للنطق، عشوائي) */
    private fun letters(r: Random, len: Int): String {
        val sb = StringBuilder()
        when (r.nextInt(7)) {
            0 -> {
                val a = rareOrAny(r)
                val b = rareOrAny(r)
                if (len == 3) sb.append(a).append(b).append(a)
                else sb.append(a).append(b).append(b).append(a)
            }
            1 -> {
                val a = rareOrAny(r)
                val b = rareOrAny(r)
                if (len == 3) {
                    sb.append(a).append(a).append(b)
                } else if (r.nextBoolean()) {
                    sb.append(a).append(a).append(b).append(b)
                } else {
                    sb.append(a).append(b).append(a).append(b)
                }
            }
            2, 3 -> {
                var consonant = r.nextBoolean()
                repeat(len) {
                    sb.append(if (consonant) CONS[r.nextInt(CONS.length)] else VOW[r.nextInt(VOW.length)])
                    consonant = !consonant
                }
            }
            else -> repeat(len) { sb.append(rareOrAny(r)) }
        }
        return sb.toString()
    }

    private fun digits(r: Random): String = when (r.nextInt(4)) {
        0 -> r.nextInt(10).toString()
        1 -> (10 + r.nextInt(90)).toString()
        2 -> {
            val d = r.nextInt(10)
            "$d$d"
        }
        else -> (100 + r.nextInt(900)).toString()
    }

    private fun tail(r: Random): String {
        val n = 1 + r.nextInt(2)
        val sb = StringBuilder()
        repeat(n) { sb.append(rareOrAny(r)) }
        return sb.toString()
    }

    fun raw(r: Random, mode: Mode): String {
        val m = if (mode == Mode.MIXED) Mode.values()[1 + r.nextInt(4)] else mode
        val len = if (r.nextInt(5) < 2) 3 else 4
        val l = letters(r, len)
        return when (m) {
            Mode.LETTERS, Mode.MIXED -> l
            Mode.DIGITS -> when (r.nextInt(3)) {
                0 -> l + digits(r)
                1 -> {
                    val k = 1 + r.nextInt(l.length - 1)
                    l.substring(0, k) + digits(r) + l.substring(k)
                }
                else -> l.substring(0, l.length - 1) + digits(r) + l.last()
            }
            Mode.UNDERSCORE -> when (r.nextInt(3)) {
                0 -> l + "_" + digits(r)
                1 -> {
                    val k = 1 + r.nextInt(l.length - 1)
                    l.substring(0, k) + "_" + l.substring(k)
                }
                else -> l + "_" + tail(r)
            }
            Mode.DOT -> when (r.nextInt(3)) {
                0 -> l + "." + digits(r)
                1 -> {
                    val k = 1 + r.nextInt(l.length - 1)
                    l.substring(0, k) + "." + l.substring(k)
                }
                else -> l + "." + tail(r)
            }
        }
    }

    /** درجة الندرة من 1 إلى 99 (0 = شائع ويُستبعد) */
    fun score(name: String): Int {
        val core = name.filter { it in 'a'..'z' }
        if (name in COMMON_WORDS) return 0
        if (core.length >= 3 && core in COMMON_WORDS) return 0

        var s = 25
        val rareCount = core.count { it in RARE }
        s += minOf(rareCount * 8, 24)
        s += when {
            name.length <= 3 -> 15
            name.length == 4 -> 10
            name.length == 5 -> 5
            else -> 0
        }
        if (core.length >= 3 && core == core.reversed()) s += 18
        if (core.length >= 2 && core.toSet().size == 1) s += 10
        if (name.contains('_') || name.contains('.')) s += 8
        val d = name.filter { it.isDigit() }
        if (d.isNotEmpty()) s += if (d in COMMON_DIGITS) -15 else 6
        if (core.length >= 3 && core.none { it in VOW }) s += 6
        return s.coerceIn(1, 99)
    }

    fun batch(
        r: Random,
        mode: Mode,
        minScore: Int,
        count: Int,
        seen: MutableSet<String>
    ): List<Candidate> {
        val out = ArrayList<Candidate>()
        var tries = 0
        while (out.size < count && tries < count * 60) {
            tries++
            val n = raw(r, mode)
            if (n.startsWith("www") || !seen.add(n)) continue
            val s = score(n)
            if (s > 0 && s >= minScore) out.add(Candidate(n, s))
        }
        out.sortByDescending { it.score }
        return out
    }
}
