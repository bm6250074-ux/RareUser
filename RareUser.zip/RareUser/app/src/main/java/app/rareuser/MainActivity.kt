package app.rareuser

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random

class MainActivity : Activity() {

    private val rnd = Random(System.nanoTime())
    private val seen = HashSet<String>()
    private val items = ArrayList<Candidate>()
    private val rows = ArrayList<String>()
    private val favs = LinkedHashSet<String>()
    private var current: List<Candidate> = emptyList()
    private var mode = Mode.MIXED
    private var minScore = 60
    private var showFav = false

    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var status: TextView
    private lateinit var favBtn: Button

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        getSharedPreferences("p", MODE_PRIVATE).getStringSet("fav", emptySet())
            ?.let { favs.addAll(it.sorted()) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(24), dp(14), dp(12))
        }

        val title = TextView(this).apply {
            text = "RareUser — يوزرات نادرة"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, rows) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.textSize = 20f
                v.typeface = Typeface.MONOSPACE
                return v
            }
        }

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            Mode.values().map { it.label }
        )
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (Mode.values()[pos] != mode || items.isEmpty()) {
                    mode = Mode.values()[pos]
                    resetList()
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(spinner)

        val scoreLabel = TextView(this).apply {
            text = "أقل درجة ندرة: $minScore"
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(scoreLabel)

        val seek = SeekBar(this).apply {
            max = 95
            progress = minScore
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                minScore = value
                scoreLabel.text = "أقل درجة ندرة: $value"
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {
                showFav = false
                favBtn.text = "المفضلة"
                resetList()
            }
        })
        root.addView(seek)

        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val moreBtn = Button(this).apply { text = "المزيد" }
        favBtn = Button(this).apply { text = "المفضلة" }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        btnRow.addView(moreBtn, lp)
        btnRow.addView(favBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(btnRow)

        status = TextView(this).apply {
            setPadding(0, dp(4), 0, dp(4))
            textSize = 13f
        }
        root.addView(status)

        val list = ListView(this)
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)

        moreBtn.setOnClickListener {
            if (showFav) {
                showFav = false
                favBtn.text = "المفضلة"
                refresh()
            } else {
                loadMore()
            }
        }
        favBtn.setOnClickListener {
            showFav = !showFav
            favBtn.text = if (showFav) "رجوع" else "المفضلة"
            refresh()
        }
        list.setOnItemClickListener { _, _, pos, _ ->
            if (pos < current.size) copy(current[pos].name)
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            if (pos < current.size) toggleFav(current[pos].name)
            true
        }
        list.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(v: AbsListView?, state: Int) {}

            override fun onScroll(v: AbsListView?, first: Int, visible: Int, total: Int) {
                if (!showFav && total > 0 && first + visible >= total - 5) loadMore()
            }
        })

        resetList()
    }

    private fun resetList() {
        seen.clear()
        items.clear()
        loadMore()
    }

    private fun loadMore() {
        items.addAll(Generator.batch(rnd, mode, minScore, 120, seen))
        refresh()
    }

    private fun refresh() {
        current = if (showFav) favs.map { Candidate(it, Generator.score(it)) } else items.toList()
        rows.clear()
        current.forEach { c ->
            rows.add((if (c.name in favs) "★ " else "") + c.name + "    [" + c.score + "]")
        }
        adapter.notifyDataSetChanged()
        status.text = (if (showFav) "المفضلة: ${favs.size}" else "المعروض: ${items.size}") +
            " • اضغط للنسخ • اضغط مطولاً للمفضلة"
    }

    private fun copy(name: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("username", name))
        Toast.makeText(this, "تم نسخ $name", Toast.LENGTH_SHORT).show()
    }

    private fun toggleFav(name: String) {
        if (!favs.add(name)) favs.remove(name)
        getSharedPreferences("p", MODE_PRIVATE).edit().putStringSet("fav", HashSet(favs)).apply()
        refresh()
    }
}
